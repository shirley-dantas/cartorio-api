// O Ajudante, por trás: recebe o pedido do painel, abre a JUCESP numa aba, acompanha o que a página faz e, quando o PDF abre,
// o baixa com a sessão dela (o certificado já entrou) e entrega ao Apps Script, que o guarda na pasta do caso.
// O endereço do Apps Script mora AQUI, e não vem do pedido: página nenhuma consegue desviar o arquivo para outro lugar.
'use strict';

const GAS_URL = 'https://script.google.com/macros/s/AKfycbz6NoiizP5ThvPWZ1ZZ_HAvJworawPrmfzCAXyCfY2n9oB8Qx4oFfYw0trGgm5liXHY/exec';
const JUCESP = 'https://www.jucesponline.sp.gov.br';
const MAX_BYTES = 10 * 1024 * 1024;
const DOCS = {
  ficha: { nome: 'Ficha cadastral completa', arquivo: 'FICHA_CADASTRAL_COMPLETA', tipo: 'FICHA_CADASTRAL_JUCESP' },
  contrato: { nome: 'Contrato social consolidado', arquivo: 'CONTRATO_SOCIAL_CONSOLIDADO', tipo: 'CONTRATO_SOCIAL' }
};

function cnpjValido(c) {
  c = String(c || '').replace(/\D/g, '');
  if (c.length !== 14 || /^(\d)\1+$/.test(c)) return false;
  const dv = (n) => { let s = 0, p = n - 7; for (let i = 0; i < n; i++) { s += Number(c[i]) * p--; if (p < 2) p = 9; } const r = s % 11; return r < 2 ? 0 : 11 - r; };
  return dv(12) === Number(c[12]) && dv(13) === Number(c[13]);
}

// Os jobs ficam no armazenamento da extensão: o service worker dorme e acorda, e a memória some.
let trava = Promise.resolve();
function mexer(f) { const p = trava.then(f); trava = p.catch(() => {}); return p; }
async function jobs() { return (await chrome.storage.local.get('jobs')).jobs || {}; }
async function guardar(j) { await chrome.storage.local.set({ jobs: j }); }
async function mudar(id, f) {
  return mexer(async () => { const todos = await jobs(), job = todos[id]; if (!job) return null; const r = await f(job, todos); await guardar(todos); return r === undefined ? job : r; });
}
async function jobDaAba(tabId) { const todos = await jobs(); return Object.values(todos).find((j) => j.jucespTabId === tabId && !j.fim) || null; }

// `fim` marca o último aviso do pedido: é por ele que o painel sabe que pode começar o próximo da fila.
function falar(job, estado, texto, fim) {
  if (job.painelTabId == null) return;
  try { Promise.resolve(chrome.tabs.sendMessage(job.painelTabId, { tipo: 'progresso', id: job.id, estado, texto, fim: !!fim })).catch(() => {}); } catch (_) { /* a aba do painel pode ter fechado */ }
}
async function terminar(id, estado, texto) {
  const job = await mudar(id, (j, todos) => { j.fim = true; j.estado = estado; j.texto = texto; ev(j, { fim: estado, texto: String(texto || '').slice(0, 90) }); if (!Object.values(todos).some((x) => !x.fim)) { popupsDaJucesp(false); bloquearTicket(false); } });
  if (job) {
    falar(job, estado, texto, true);
    try { Promise.resolve(chrome.tabs.sendMessage(job.jucespTabId, { tipo: 'fim', estado, texto })).catch(() => {}); } catch (_) { /* a aba pode já ter fechado */ }
  }
}

function paraBase64(buffer) {
  const b = new Uint8Array(buffer); let s = '';
  for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
  return btoa(s);
}

// O NIRE de cada CNPJ, aprendido na primeira busca: da segunda vez em diante o Ajudante vai direto à empresa e pula a pesquisa
// (e o captcha que ela traz). Se a JUCESP não deixar entrar direto, a página cai na pesquisa e o caminho de sempre continua.
async function nireConhecido(cnpj) { return ((await chrome.storage.local.get('nires')).nires || {})[cnpj] || null; }
async function lembrarNire(cnpj, nire) { await mexer(async () => { const n = (await chrome.storage.local.get('nires')).nires || {}; n[cnpj] = nire; await chrome.storage.local.set({ nires: n }); }); }

// A JUCESP abre o PDF numa janela nova, e o Chrome bloqueia essa janela quando o clique que a causou é de programa. Enquanto há pedido andando,
// os pop-ups SÓ do site da JUCESP ficam liberados (configuração da própria extensão, que o Chrome desfaz quando ela a limpa). Nada além desse endereço.
const PADRAO_JUCESP = JUCESP + '/*';
async function popupsDaJucesp(liberar) {
  try {
    const cs = chrome.contentSettings && chrome.contentSettings.popups; if (!cs) return 'sem a API';
    if (liberar) await cs.set({ primaryPattern: PADRAO_JUCESP, setting: 'allow' }); else await cs.clear({});
    return 'ok';
  } catch (e) { return 'erro: ' + String((e && e.message) || e).slice(0, 120); }   // a reserva da faixa (um clique dela) cobre
}
// O endereço do PDF (VisualizaTicket.aspx?sc=…) vale UMA vez: quando o Chrome o abre, o Ajudante já não consegue baixá-lo (foi o que o teste real mostrou:
// o PDF abria para ela e o card dizia "O que veio não é um PDF"). Então, enquanto há pedido andando, a NAVEGAÇÃO a esse endereço é bloqueada (regra do
// declarativeNetRequest, só para janelas e quadros — a busca do Ajudante é outro tipo e passa) e o Ajudante o baixa ele mesmo, uma vez só.
const REGRA_TICKET = 7001;
async function bloquearTicket(ligar) {
  try {
    const d = chrome.declarativeNetRequest; if (!d || !d.updateDynamicRules) return 'sem a API';
    await d.updateDynamicRules({ removeRuleIds: [REGRA_TICKET], addRules: ligar ? [{ id: REGRA_TICKET, priority: 1, action: { type: 'block' }, condition: { urlFilter: '||www.jucesponline.sp.gov.br/VisualizaTicket.aspx', resourceTypes: ['main_frame', 'sub_frame'] } }] : [] });
    return 'ok';
  } catch (e) { return 'erro: ' + String((e && e.message) || e).slice(0, 120); }
}
// Uma regra esquecida (a extensão fechou no meio) bloquearia os PDFs dela para sempre: ao acordar, sem pedido andando, a regra sai.
(async () => { try { const todos = await jobs(); if (!Object.values(todos).some((x) => !x.fim)) await bloquearTicket(false); } catch (_) { /* sem armazenamento ainda */ } })();

// O que o fundo viu, para o relatório: se os pop-ups foram liberados, que abas a página abriu, o que foi baixado e como acabou.
const ev = (job, o) => { (job.eventos = job.eventos || []).push(Object.assign({ t: Math.round((Date.now() - (job.iniciado || Date.now())) / 100) / 10 }, o)); if (job.eventos.length > 20) job.eventos.shift(); };
const semQuery = (u) => { try { const x = new URL(u); return x.pathname; } catch (_) { return String(u || '').split('?')[0]; } };

async function criarPedido(pedido, sender) {
  const quero = Array.isArray(pedido && pedido.quero) ? pedido.quero.filter((q, i, a) => DOCS[q] && a.indexOf(q) === i) : [];
  if (!quero.length) return { ok: false, texto: 'Não entendi o que buscar.' };
  if (!/^[A-Za-z0-9_-]{6,40}$/.test(String((pedido && pedido.casoId) || ''))) return { ok: false, texto: 'Caso inválido.' };
  if (!/^[A-Za-z0-9_-]{4,40}$/.test(String((pedido && pedido.id) || ''))) return { ok: false, texto: 'Pedido inválido.' };
  if (!cnpjValido(pedido.cnpj)) return { ok: false, texto: 'Esse CNPJ não confere (confira os dígitos).' };
  // O contrato consolidado se acha pelo número que a ficha cadastral traz (a lista da JUCESP quase não tem descrição): a ficha vai primeiro, e fica no card.
  if (quero.includes('contrato')) { if (!quero.includes('ficha')) quero.push('ficha'); quero.sort((a, b) => (a === 'ficha' ? 0 : 1) - (b === 'ficha' ? 0 : 1)); }
  const job = { id: pedido.id, casoId: pedido.casoId, cnpj: String(pedido.cnpj).replace(/\D/g, ''), fila: quero.slice(), feitos: [], painelTabId: sender && sender.tab ? sender.tab.id : null, iniciado: Date.now() };
  const conhecido = await nireConhecido(job.cnpj);
  if (conhecido) { job.nire = conhecido; job.direto = true; }
  job.popups = await popupsDaJucesp(true);
  job.bloqueio = await bloquearTicket(true);
  const aba = await chrome.tabs.create({ url: conhecido ? JUCESP + '/Pre_Visualiza.aspx?nire=' + conhecido + '&idproduto=' : JUCESP + '/Default.aspx' });
  job.jucespTabId = aba.id;
  await mexer(async () => { const todos = await jobs(); todos[job.id] = job; await guardar(todos); });
  falar(job, 'andando', 'Abrindo a JUCESP…');
  return { ok: true };
}

async function enviarAoApps(job, qual, base64) {
  const d = DOCS[qual];
  const corpo = {
    acao: 'painel-arquivo', casoId: job.casoId, nomeArquivo: 'JUCESP_' + d.arquivo + '_' + job.cnpj + '.pdf', mimetype: 'application/pdf',
    base64, tipoSugerido: d.tipo, pessoaSugerida: job.empresa || '', origemAjudante: 'jucesp'
  };
  const r = await fetch(GAS_URL, { method: 'POST', body: JSON.stringify(corpo) });
  const txt = await r.text();
  let j; try { j = JSON.parse(txt); } catch (_) { throw new Error('O Apps Script não respondeu em JSON (precisa de nova versão?).'); }
  if (!j || !j.ok) throw new Error((j && j.erro) || 'O Apps Script recusou o arquivo.');
  return j;
}

// O PDF já em mãos (base64): confere, entrega ao Apps Script e anda a fila. Quem o trouxe — a aba do pedido, que o baixou pelo formulário,
// ou o endereço que abriu — não importa daqui para frente.
async function guardarPdf(job, base64) {
  const qual = job.fila[0], d = DOCS[qual];
  if (!d) return;
  try {
    if (!String(base64 || '').startsWith('JVBERi')) throw new Error('O que veio não é um PDF.');
    if (base64.length * 0.75 > MAX_BYTES) throw new Error('PDF maior que 10 MB.');
    const j = await enviarAoApps(job, qual, base64);
    if (job.abaDoPdf != null && job.abaDoPdf !== job.jucespTabId) { try { Promise.resolve(chrome.tabs.remove(job.abaDoPdf)).catch(() => {}); } catch (_) { /* já fechou */ } }   // a aba extra só existia para mostrar o PDF
    const atual = await mudar(job.id, (x) => { x.feitos.push(qual); x.fila.shift(); x.pdfUrl = null; x.abaDoPdf = null; x.manual = false; if (qual === 'ficha') { x.fichaLida = true; x.consolidacao = (j && j.consolidacao) || null; } });
    const msg = d.nome + ': guardado no card como ' + j.nome + (j.confirmar ? ' (confirme o nome no card)' : '') + '.';
    if (atual.fila.length) { falar(atual, 'andando', msg + ' Agora: ' + DOCS[atual.fila[0]].nome + '…'); await irParaEmpresa(atual); }
    else {
      await terminar(job.id, 'ok', 'Pronto! ' + msg);
      // O PDF tentava abrir na própria aba do pedido, e o bloqueio a deixou numa página de erro: devolve-a ao site, em vez de deixá-la assim para ela.
      if (job.abaDoPdf != null && job.abaDoPdf === job.jucespTabId) { try { await chrome.tabs.update(job.jucespTabId, { url: JUCESP + '/Default.aspx' }); } catch (_) { /* a aba pode ter fechado */ } }
    }
  } catch (e) {
    await mudar(job.id, (x) => { x.pdfUrl = null; });
    await terminar(job.id, 'erro', 'Não consegui guardar ' + d.nome + ': ' + ((e && e.message) || e) + ' Salve o PDF (Ctrl+S) e arraste para a caixa do card.');
  }
}

// A aba do pedido pode ter virado a página de erro do bloqueio (o PDF tentava abrir NELA) e já não serve para baixar. Então abre-se uma aba auxiliar do site
// da JUCESP — mesma origem, mesmos cookies —, o PDF é buscado de dentro dela uma vez e a aba fecha. Roda no mundo da página, onde o cookie `SameSite` é o dela.
function baixarNaPagina(u) {
  return fetch(u, { credentials: 'same-origin' }).then(async (r) => {
    const b = new Uint8Array(await r.arrayBuffer()), ok = b.length > 4 && String.fromCharCode(b[0], b[1], b[2], b[3]) === '%PDF';
    let t = ''; if (ok) for (let i = 0; i < b.length; i += 0x8000) t += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
    return { ok, base64: ok ? btoa(t) : '', status: r.status, tipo: r.headers.get('content-type') || '' };
  }).catch((e) => ({ ok: false, erro: String((e && e.message) || e) }));
}
async function buscarPelaAbaAuxiliar(url) {
  if (!chrome.scripting || !chrome.scripting.executeScript) return { ok: false, erro: 'sem a API scripting' };
  const aba = await chrome.tabs.create({ url: JUCESP + '/Default.aspx', active: false });
  try {
    for (let i = 0; i < 40; i++) { const t = await chrome.tabs.get(aba.id); if (t && t.status === 'complete') break; await new Promise((r) => setTimeout(r, 400)); }
    const [res] = await chrome.scripting.executeScript({ target: { tabId: aba.id }, func: baixarNaPagina, args: [url] });
    return (res && res.result) || { ok: false, erro: 'sem resultado' };
  } catch (e) { return { ok: false, erro: String((e && e.message) || e).slice(0, 120) }; }
  finally { try { await chrome.tabs.remove(aba.id); } catch (_) { /* já fechou */ } }
}

// O PDF abriu numa aba (a do pedido ou uma nova): baixa pelo endereço, com a sessão dela.
async function capturar(job, url) {
  const d = DOCS[job.fila[0]];
  if (!d) return;
  falar(job, 'andando', 'Baixando: ' + d.nome + '…');
  try { Promise.resolve(chrome.tabs.sendMessage(job.jucespTabId, { tipo: 'pdf' })).catch(() => {}); } catch (_) { /* a aba pode estar mudando de página */ }
  try {
    // Primeiro pela aba da JUCESP (a sessão e os cookies são os dela); só se a aba não puder, pelo fundo.
    let base64 = null;
    let viaAba = 'sem resposta';
    try { const r = await chrome.tabs.sendMessage(job.jucespTabId, { tipo: 'buscar-pdf', url }); if (r && r.ok && r.base64) { base64 = r.base64; viaAba = 'ok'; } else if (r) viaAba = 'não é PDF (' + (r.status || '?') + ', ' + (r.tipo || r.erro || '?') + ')'; } catch (_) { viaAba = 'aba indisponível'; }
    await mudar(job.id, (x) => { ev(x, { buscaPelaAba: viaAba }); });
    if (!base64) {
      const r = await buscarPelaAbaAuxiliar(url);
      if (r && r.ok && r.base64) base64 = r.base64;
      await mudar(job.id, (x) => { ev(x, { buscaPelaAbaAuxiliar: r && r.ok ? 'ok' : 'falhou (' + ((r && (r.erro || r.status + ' ' + r.tipo)) || '?') + ')' }); });
    }
    if (!base64) {
      const r = await fetch(url, { credentials: 'include' });
      if (!r.ok) throw new Error('A JUCESP respondeu ' + r.status + ' ao baixar o PDF.');
      const bytes = await r.arrayBuffer();
      await mudar(job.id, (x) => { ev(x, { buscaPeloFundo: r.status + ' ' + (r.headers.get('content-type') || '?') + ' ' + bytes.byteLength + 'B' }); });
      if (!bytes.byteLength) throw new Error('PDF vazio.');
      base64 = paraBase64(bytes);
    }
    await guardarPdf(job, base64);
  } catch (e) {
    await mudar(job.id, (x) => { x.pdfUrl = null; });
    await terminar(job.id, 'erro', 'Não consegui guardar ' + d.nome + ': ' + ((e && e.message) || e) + ' Salve o PDF (Ctrl+S) e arraste para a caixa do card.');
  }
}

async function irParaEmpresa(job) {
  if (job.nire) await chrome.tabs.update(job.jucespTabId, { url: JUCESP + '/Pre_Visualiza.aspx?nire=' + job.nire + '&idproduto=' });
  else await chrome.tabs.update(job.jucespTabId, { url: JUCESP + '/Default.aspx' });
}

chrome.runtime.onMessage.addListener((m, sender, responder) => {
  (async () => {
    if (!m) return responder(null);
    if (m.tipo === 'pedido') return responder(await criarPedido(m.pedido, sender));
    const job = sender && sender.tab ? await jobDaAba(sender.tab.id) : null;
    if (m.tipo === 'quem') return responder(job);
    if (m.tipo === 'cancelar') {
      const todos = await jobs(), alvo = todos[m.id];
      if (alvo && sender.tab && sender.tab.id === alvo.painelTabId) await terminar(m.id, 'erro', 'Cancelado.');
      return responder({ ok: true });
    }
    if (!job) return responder(null);
    // Um erro da página não encerra o pedido: ela pode escolher "Fazer à mão" e o PDF ainda será pego.
    if (m.tipo === 'status') { if (m.fatal) await terminar(job.id, 'erro', String(m.texto || '')); else falar(job, m.estado, m.texto); return responder({ ok: true }); }
    if (m.tipo === 'nire') {
      const x = await mudar(job.id, (j) => { j.nire = String(m.nire || '').replace(/\D/g, '') || j.nire; if (m.empresa) j.empresa = String(m.empresa).slice(0, 120); });
      if (m.empresa && x && /^\d{11}$/.test(x.nire || '')) await lembrarNire(x.cnpj, x.nire);   // só o que veio do resultado da busca por esse CNPJ
      return responder({ ok: true });
    }
    if (m.tipo === 'diagnostico-fundo') return responder({ popups: job.popups || '', bloqueio: job.bloqueio || '', eventos: job.eventos || [] });
    // A aba do pedido pediu o PDF pelo formulário e o trouxe de volta (sem abrir aba nenhuma): é o caminho normal.
    if (m.tipo === 'pdf-bytes') { responder({ ok: true }); await guardarPdf(job, String(m.base64 || '')); return; }
    if (m.tipo === 'manual') { await mudar(job.id, (x) => { x.manual = true; }); return responder({ ok: true }); }
    responder(null);
  })().catch(() => responder(null));
  return true;
});

// O PDF abre na própria aba; é aí que ele é pego. Vale tanto para o caminho automático quanto para quando ela assumiu à mão.
// O PDF abre na própria aba do pedido ou numa aba nova aberta por ela (a JUCESP faz as duas coisas, conforme o botão).
function avisarTicket(tabId, url, opener) {
  mexer(async () => {
    const todos = await jobs(), job = Object.values(todos).find((j) => !j.fim && (j.jucespTabId === tabId || (j.filhas || []).includes(tabId) || (opener != null && j.jucespTabId === opener)));
    if (!job || job.pdfUrl === url) return null;
    job.pdfUrl = url; job.abaDoPdf = tabId; ev(job, { pdfEm: semQuery(url), aba: tabId === job.jucespTabId ? 'a do pedido' : 'nova' }); await guardar(todos); return job;
  }).then((job) => { if (job) return capturar(job, url); }).catch(() => {});
}
chrome.tabs.onUpdated.addListener((tabId, info, aba) => {
  const url = (aba && aba.url) || info.url || '';
  if (!/\/VisualizaTicket\.aspx/i.test(url) || new URL(url).origin !== JUCESP) return;
  avisarTicket(tabId, url, aba && aba.openerTabId);
});

chrome.tabs.onCreated && chrome.tabs.onCreated.addListener((aba) => {
  if (!aba || aba.openerTabId == null) return;
  mudar_se_job_da_aba(aba.openerTabId, (j) => { ev(j, { abaCriada: semQuery(aba.pendingUrl || aba.url || '') || '(sem endereço)' }); (j.filhas = j.filhas || []).push(aba.id); });
});

// O Chrome avisa que vai navegar ao endereço do PDF ANTES de pedi-lo (e a regra acima impede o pedido): é a hora de baixá-lo, uma vez só.
chrome.webNavigation && chrome.webNavigation.onBeforeNavigate.addListener((d) => {
  if (!d || !/\/VisualizaTicket\.aspx/i.test(d.url || '')) return;
  let origem; try { origem = new URL(d.url).origin; } catch (_) { return; }
  if (origem !== JUCESP) return;
  avisarTicket(d.tabId, d.url);
});
async function mudar_se_job_da_aba(tabId, f) {
  const todos = await jobs(), job = Object.values(todos).find((j) => !j.fim && j.jucespTabId === tabId);
  if (job) await mudar(job.id, f);
}

chrome.tabs.onRemoved.addListener((tabId) => {
  mexer(async () => { const todos = await jobs(); const job = Object.values(todos).find((j) => j.jucespTabId === tabId && !j.fim); return job ? { ...job } : null; })
    .then((job) => { if (job) return terminar(job.id, 'erro', 'A aba da JUCESP foi fechada antes de terminar.'); }).catch(() => {});
});

if (typeof module !== 'undefined') module.exports = { cnpjValido, paraBase64, DOCS };
